# THE.GOV.GE - Thermal Helium Extraction
Testing version of [the.gov.ge](https://the.gov.ge/) website written in flask (python).

Run application:
```sh
$ cd app
$ flask run
```

License
----
MIT
